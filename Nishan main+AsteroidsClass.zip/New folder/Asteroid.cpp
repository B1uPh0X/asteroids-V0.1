#include "Asteroid.h"
#include <random>

Asteroid::Asteroid()
{
    //int design = "rand()% x-1";  //
}

Asteroid::~Asteroid()
{
    //dtor
}
